{{usage}}

### pipx install

{{install}}

### pipx install-all

{{installall}}

### pipx uninject

{{uninject}}

### pipx inject

{{inject}}

### pipx upgrade

{{upgrade}}

### pipx upgrade-all

{{upgradeall}}

### pipx upgrade-shared

{{upgradeshared}}

### pipx uninstall

{{uninstall}}

### pipx uninstall-all

{{uninstallall}}

### pipx reinstall

{{reinstall}}

### pipx reinstall-all

{{reinstallall}}

### pipx list

{{list}}

### pipx interpreter

{{interpreter}}

### pipx run

{{run}}

### pipx runpip

{{runpip}}

### pipx ensurepath

{{ensurepath}}

### pipx environment

{{environment}}

### pipx completions

{{completions}}
